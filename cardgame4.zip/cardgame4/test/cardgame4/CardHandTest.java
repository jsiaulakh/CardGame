/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardgame4;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jsiau
 */
public class CardHandTest {
    
    public CardHandTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of generateHand method, of class CardHand.
     */
 

    /**
     * Test of run method, of class CardHand.
     */
    @Test
    public void testRun() {
        System.out.println("run");
        CardHand i = new CardHand();
        i.generateHand();
        assertFalse(i.run(0));
        assertFalse(i.run(25));
        assertTrue(i.run(26));
        assertFalse(i.run(27));
        assertFalse(i.run(52));
    }
    
}
